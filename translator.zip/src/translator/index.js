function translate(str) {
  return 'translated ' + str
}

module.exports = {
  translate
}
