console.log('hello webpack')

const obj = {
  'a': '1',
  'b': '2'
}
