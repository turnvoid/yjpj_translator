module.exports = {
    worksInfo: {
        inspector: '督学',
        processing: '流程中',
        allProcess: '总流程'
    }
}