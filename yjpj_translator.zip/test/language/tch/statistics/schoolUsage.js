module.exports = {
    // 头部菜单
    table_header: {
        index: '序號',
        shcoolName: '學校名稱',
        provinceName: '省份名稱',
        cityName: '都市名稱',
        num: '教師使用量',
        totalTeachersNum: '教師總數',
        rate: '使用率',
        radar: '雷達圖'
    }
}