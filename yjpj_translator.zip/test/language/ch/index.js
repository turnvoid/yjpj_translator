const dashboard = require('./dashboard')
const statistics = require('./statistics')

module.exports = {
  dashboard,
  statistics
}
