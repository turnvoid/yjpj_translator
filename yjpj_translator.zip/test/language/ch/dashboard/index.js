const workspace = require('./workspace')

module.exports = {
  workspace
}
