module.exports = {
  // 头部菜单
  card_title: {
      processing: '流程中',
      fastMenu: '快捷导航',
      dynamic: '最新动态'
  },
  card_content: {
    inspectof: '督学',
    created: '创建了'
  }
}
