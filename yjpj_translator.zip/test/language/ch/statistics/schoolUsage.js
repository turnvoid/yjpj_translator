module.exports = {
  // 头部菜单
  table_header: {
      index: '序号',
      shcoolName: '学校名称',
      provinceName: '省份名称',
      cityName: '城市名称',
      num: '教师使用量',
      totalTeachersNum: '教师总数',
      rate: '使用率',
      radar: '雷达图'
  }
}
