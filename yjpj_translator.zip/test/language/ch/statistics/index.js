const schoolUsage = require('./schoolUsage')

module.exports = {
  schoolUsage
}
